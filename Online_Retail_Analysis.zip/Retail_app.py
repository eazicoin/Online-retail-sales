import streamlit as st
import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt

# Load trained model & label encoder
rfc_model = joblib.load("customer_segmentation_model.pkl")
label_encoder = joblib.load("label_encoder.pkl") 

# Authentication System
USER_CREDENTIALS = {"Godwill": "password123"}

def check_login():
    return st.session_state.get("logged_in", False)

def login():
    st.markdown("<h2 style='text-align: center;'> Online Retail Dashboard</h2>", unsafe_allow_html=True)
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        if username in USER_CREDENTIALS and USER_CREDENTIALS[username] == password:
            st.session_state["logged_in"] = True
            st.session_state["username"] = username
            st.rerun()
        else:
            st.error("Invalid username or password. Try again!")

def logout():
    st.session_state["logged_in"] = False
    st.rerun()

# Function to predict customer segment (returns string label)
def predict_segment(recency, frequency, monetary):
    input_data = np.array([[recency, frequency, monetary]])  
    prediction_numeric = rfc_model.predict(input_data)[0]
    prediction_label = label_encoder.inverse_transform([prediction_numeric])[0]  # Convert number to label
    return prediction_label  

# Function to generate AI report
def generate_report(df_updated, segment, recency, frequency, monetary):
    report = f"""
    ### Customer Insights

    #### Customer Segmentation Overview
    - Most common segment: **"{df_updated['Customer_Segment'].value_counts().idxmax()}"**
    - Least common segment: **"{df_updated['Customer_Segment'].value_counts().idxmin()}"**
    - Unique segments: **{df_updated['Customer_Segment'].nunique()}**

    #### Prediction Insights
    - Predicted segment: **"{segment}"**
    - Recency: **{recency} days since last purchase**
    - Frequency: **{frequency} total purchases**
    - Monetary Value: **${monetary}**

    #### Business Recommendations
    - **Loyal Customers:** Offer exclusive deals or loyalty programs.
    - **Churn Risk:** Send personalized re-engagement emails.
    - **High-Value Customers:** Provide VIP customer service.

    #### Conclusion
    - Understanding customer segments improves marketing and retention.
    - Tracking segments ensures a balanced, profitable customer base.

    _Created by Okwuchukwu Godwill Tochukwu_
    """
    return report

# Streamlit Page Configuration
st.set_page_config(page_title="Online Retail Analysis", layout="wide")

if not check_login():
    login()
else:
    st.markdown("<h1 style='text-align: center; color: #007bff;'>Online Retail Analysis</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='text-align: center; color: #495057;'>Customer Segmentation Prediction</h3>", unsafe_allow_html=True)

    with st.sidebar:
        st.subheader(f"Welcome, {st.session_state['username']}")
        if st.button("Logout"):
            logout()

    col1, col2, col3 = st.columns(3)
    with col1:
        recency = st.number_input("Recency (days since last purchase)", min_value=0, max_value=374)
    with col2:
        frequency = st.number_input("Frequency (total purchases)", min_value=1, max_value=210)
    with col3:
        monetary = st.number_input("Monetary Value (total spend)", min_value=0, max_value=280206)

    df = pd.read_csv("C:/Users/PC/Desktop/ORTD/customer_segmentation.csv")

    if "predicted_data" not in st.session_state:
        st.session_state["predicted_data"] = df.copy()

    if st.button("Predict Customer Segment", help="Click to Predict Customer's Segment"):
        segment = predict_segment(recency, frequency, monetary)
        st.session_state.segment_prediction = segment
        st.success(f"Predicted Segment: {segment}")

        new_data = pd.DataFrame([[recency, frequency, monetary, segment]], 
                                columns=["Recency", "Frequency", "Monetary", "Customer_Segment"])
        st.session_state["predicted_data"] = pd.concat([st.session_state["predicted_data"], new_data], ignore_index=True)

    df_updated = st.session_state["predicted_data"]

    if "segment_prediction" in st.session_state:
        st.sidebar.subheader("Generated Report")
        report = generate_report(df_updated, st.session_state.segment_prediction, recency, frequency, monetary)
        st.sidebar.write(report)

    st.markdown("<h2 style='text-align: center; color: #007bff;'>Customer Insights & Analysis</h2>", unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Customer Segment Distribution")
        segment_counts = df_updated["Customer_Segment"].value_counts()
        fig_pie = px.pie(
            names=segment_counts.index, 
            values=segment_counts.values,
            title="Overall Customer Segments",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        st.plotly_chart(fig_pie)

    with col2:
        st.subheader("Spending vs. Purchase Frequency")
        fig_scatter = px.scatter(
            df_updated, x="Frequency", y="Monetary",
            color="Customer_Segment",
            title="Customer Spending Behavior",
            labels={"Frequency": "Total Purchases", "Monetary": "Total Spend ($)"},
            size_max=10
        )
        st.plotly_chart(fig_scatter)

    col3, col4 = st.columns(2)

    with col3:
        st.subheader("Customer Recency vs. Frequency")
        fig_box = px.box(
            df_updated, 
            x="Recency", 
            y="Frequency", 
            color="Customer_Segment",
            title="Distribution of Purchase Frequency Across Recency",
            labels={"Recency": "Days Since Last Purchase", "Frequency": "Total Purchases"},
            boxmode="group"
        )
        st.plotly_chart(fig_box)

    with col4:
        st.subheader("Top Customer Segments")
        fig_bar = px.bar(
            segment_counts,
            x=segment_counts.index,
            y=segment_counts.values,
            title="Most Common Customer Segments",
            color=segment_counts.index,
            labels={"x": "Segment", "y": "Count"},
            text_auto=True
        )
        st.plotly_chart(fig_bar)
